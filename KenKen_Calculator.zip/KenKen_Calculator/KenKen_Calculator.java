import java.util.*;

public class KenKen_Calculator {
    static int max = 12;
    final static String INDENTER = "  ";
    
    public static void multiplication(int value, int spaces, int i, int indentLevel) {
        boolean isSubChain = false;
        while (Math.pow(i, spaces) >= value) {
            if (value % i ==0) {
                if (isSubChain) {
                    for (int x = 1; x<=indentLevel; x++)
                        System.out.print(INDENTER);
                }
                
                System.out.print(i + " ");
  
                if (spaces > 1){
                    multiplication(value/i, spaces-1, i, indentLevel+1);
                    isSubChain = true;
                }
                else 
                    System.out.println();
            }
            i--;
        }
    }      


   public static void main(String []args) {
      multiplication(24, 4, max, 0);
   }
} 