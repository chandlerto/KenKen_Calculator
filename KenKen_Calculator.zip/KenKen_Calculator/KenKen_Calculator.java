import java.util.*;

public class KenKen_Calculator {
    static int max = 12;
    final static String INDENTER = "  ";
    ArrayList<int[]> returnGrid = new ArrayList();
    
    public static int[] multiplication(int value, int spaces, int i, int row, int col) {
        boolean isSubChain = false;
        boolean noSolutionsFound = true;
        int returnValue;
        int returnRow;
        int returnCol;
        while (Math.pow(i, spaces) >= value) {
            if (value % i ==0) {
                if (isSubChain) {
                    for (int x = 1; x<=col; x++)
                        System.out.print(INDENTER);
                }
                
                System.out.print(i + " ");
  
                if (spaces > 1){
                    multiplication(value/i, spaces-1, i, col+1, row);
                    isSubChain = true;
                    noSolutionsFound = false;
                }
                else 
                    row++;
            }
            i--;
        }
        if (noSolutionsFound)
            row ++;
    }      


   public static void main(String []args) {
      multiplication(24, 4, max, 0, 0);
   }
} 