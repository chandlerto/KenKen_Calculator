
public class KenKen_Calculator {

    public static void multiplication(int value, int spaces, int i) {
        while (Math.pow(i, spaces) >= value) {
            if (value % i ==0) {
                System.out.print(i + " ");
                if (spaces > 1)
                    multiplication(value/i, spaces-1, i);
                else 
                    System.out.println();
            }
            i--;
        }
    }      


   public static void main(String []args) {
      multiplication(24, 4, 12);
   }
} 