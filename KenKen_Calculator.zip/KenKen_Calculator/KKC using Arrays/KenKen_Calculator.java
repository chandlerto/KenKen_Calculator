import java.util.*;

public class KenKen_Calculator {
   
    /*
     * Program is currently not object oriented right now. Not really necessary, but should probably be done
     */
    static int product = 24;
    static int max = 6;
    static int theRow = 0;
    public static int spaces = 4;
    static int[] emptyArray = new int [spaces];
     
    static ArrayList<int[]> gridM = new ArrayList<int[]>();
    static ArrayList<int[]> gridA = new ArrayList<int[]>();
    static ArrayList<int[]> gridS = new ArrayList<int[]>();
    static ArrayList<int[]> gridD = new ArrayList<int[]>();
    

    public static void multiplication(int product, int spaces, int currentHigh, int col) {
        /*Used to tell when a subchain can't be completed, and a new row should be
          started. This will create rows not containing a product in the last spot, so
          a function will go through the ArrayList<int[][]> and delete those rows.*/
        boolean noSolutionsFound = true;
        
        /*EXPLANATION OF LOGIC BEHIND HOW WHILE CONDITION WORKS
         
          While statement checks if current factor being checked is possible to chain off
          Algorithm is designed that sets of possible products will always be in descending 
          order, so a product can't be greater than any of the products to its left. So we know 
          that the rest of the products to finish the subchain will be equal to or smaller than
          the factor being checked. If the factor^the number of spaces left is smaller than 
          the product we're trying to reach, it's not even possible and we should be done 
          checking for this call of the function*/
        while (Math.pow(currentHigh, spaces) >= product) {
            if (product % currentHigh ==0) {
                Array_Handler.saveNum(gridM,currentHigh,theRow,col);
  
                /*So if we aren't on the last number, we call the function again*/
                if (spaces > 1){
                    multiplication(product/currentHigh, spaces-1, currentHigh, col+1);
                    noSolutionsFound = false;
                } 
            }
            currentHigh--;
        }
        
        /*Checks at end of function call. If true, this means that a subchain was created
           that wasn't able to complete, so the row should be abandoned.*/
        if (noSolutionsFound)
            theRow ++;
            
    }      
    
    public static void addition (int sum, int spaces, int currentHigh, int col) {
        while (currentHigh*spaces >= sum) {
        
            if (currentHigh+spaces-1 <= sum) {
                
                Array_Handler.saveNum(gridA,currentHigh, theRow, col);
                
                if (spaces >1) {
                    addition(sum-currentHigh, spaces-1, currentHigh, col+1);
                }
                else
                    theRow++;
                
            }    
            currentHigh--;
        }
        
    }
    
    public static void subtraction(int difference, int max) {
        for (int i = difference+1; i <= max ; i++) {
            Array_Handler.saveNum(gridS, i, theRow, 0);
            Array_Handler.saveNum(gridS, i-difference, theRow, 1);
            theRow++;
        }
    }
    
    public static void division(int quotient, int max) {
        for (int i = quotient; i<=max ; i++) {
            if (i % quotient ==0) {
                Array_Handler.saveNum(gridD, i, theRow, 0);
                Array_Handler.saveNum(gridD, i/quotient, theRow, 1);
                theRow++;
            }
        }
    }

   public static void main(String []args) {
      /*
      Array_Handler.emptyArray(gridM, theRow, 100);
      multiplication(product, spaces, max, 0);
      //Array_Handler.fillInArray(grid);
      Array_Handler.printGrid(gridM);
      */
      theRow = 0;
      Array_Handler.emptyArray(gridA, theRow, 100);
      addition(12, spaces, 6, 0);
      Array_Handler.printGrid(gridA);
      
      System.out.println("Done");
   }
} 