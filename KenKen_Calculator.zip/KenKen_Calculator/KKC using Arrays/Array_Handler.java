import java.util.*;

/*
 * What to add
 * 1) Add calculation to format for numbers of different digit sizes
 * 2) Have ArrayList able to grow larger as necessary
 */

public class Array_Handler
{
    public static void printGrid(ArrayList<int[]> grid) {
        for (int i = 0; i<grid.size(); i++){
            
            /*
            * The ArrayList<int[]> read is created full of 0s, so after it is filled with the list of factors,
            * so unused rows and unfinished solutions will have 0s at the end.
            */
            if (grid.get(i)[grid.get(i).length-1] != 0){
                
                for (int j = 0; j<grid.get(i).length; j++){
                    
                    if (grid.get(i)[j] != 0)
                        System.out.print("   " + grid.get(i)[j]);
                    else
                        System.out.print("    ");
                        
                }
                System.out.println();
            }
        }
    }
    
    public static void saveNum(ArrayList<int[]> grid, int num, int row, int col){
        grid.get(row)[col] = num;
    }
    
    public static void emptyArray(ArrayList<int[]> grid, int row, int size){
        for (int i =0; i<size; i++){
            grid.add(i, new int[KenKen_Calculator.spaces]);
        }
    }
    
    public static void fillInArray(ArrayList<int[]> grid) {
        for (int i = 1; i<grid.size(); i++){
            for (int j = 0; j<grid.get(i).length-1; j++){
                if (grid.get(i)[j] == 0 )
                    grid.get(i)[j] = grid.get(i-1)[j];
            }
        }
    }
}   
