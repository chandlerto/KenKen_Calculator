import java.util.*;

public class KenKen_Calculator {
    
    // The highest possible factor of the set. Will be the size of the puzzle the user enters.
    static int factor = 12;
    
    //Used for indenting purposes in the print system. Will be removed.
    final static String INDENTER = "  ";
    
    //Where the factors and their information will be stored. 
    ArrayList<int[][]> returnGrid = new ArrayList();
    
    public static int[][] multiplication(int value, int spaces, int factor, int row, int col) {
        /*Used in print system to track col for subchains. Will be removed*/
        boolean isSubChain = false;
        
        /*Used to tell when a subchain can't be completed, and a new row should be
          started. This will create rows not containing a value in the last spot, so
          a function will go through the ArrayList<int[][]> and delete those rows.*/
        boolean noSolutionsFound = true;
        
        /*The array to be returned. Contains all the eligible factors found by the current
          iteration of the function, as well as the other information about them.
          Inner arrays set at 3 to contain 4 values: row, col, num of subchains, value
          Outer array set at arbitrary value. Will need to make a function to be able to 
          adapt its size for larger calculations.*/
        int[][] returnArrayArray = new int[3][5];
        
        /*EXPLANATION OF LOGIC BEHIND HOW WHILE CONDITION WORKS
         
          While statement checks if current factor being checked is possible to chain off
          Algorithm is designed that sets of possible values will always be in descending 
          order, so a value can't be greater than any of the values to its left. So we know 
          that the rest of the values to finish the subchain will be equal to or smaller than
          the factor being checked. If the factor^the number of spaces left is smaller than 
          the value we're trying to reach, it's not even possible and we should be done 
          checking for this call of the function*/
        while (Math.pow(factor, spaces) >= value) {
            //If the factor is indeed a factor of the value
            if (value % factor ==0) {
                
                /*This segment is for printing system only. Tells what column the number 
                  should be in and indents appropriately.
                   */
                if (isSubChain) {
                    for (int x = 1; x<=col; x++)
                        System.out.print(INDENTER);
                }
                
                /*Printing out the number and giving a space to represent col++ */
                System.out.print(factor + " ");
  
                /*So if we aren't on the last number, we call the function again
                  isSubChain is used for indenting in printing system, will be removed
                  noSolutionsFound is now untrue because this call of the function has
                  found an eligible factor and is currently still using the chain.*/
                if (spaces > 1){
                    multiplication(value/factor, spaces-1, factor, col+1, row);
                    isSubChain = true;
                    noSolutionsFound = false;
                }
                else 
                    row++;
            }
            
            factor--;
        }
        
        /*Checks at end of function call. If true, this means that a subchain was created
           that wasn't able to complete, so the row should be abandoned.*/
        if (noSolutionsFound)
            row ++;
            
        return returnArrayArray;
    }      


   public static void main(String []args) {
      multiplication(24, 4, factor, 0, 0);
   }
} 