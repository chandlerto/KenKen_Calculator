import java.util.*;

public class Array_Handler
{
    //in the int[] dataPoint, 0 value is value, 1 is row, 2 is column
    public static void insertIntoArray(int[] dataPoint, ArrayList<int[]> grid) {
        grid.get(dataPoint[1])[dataPoint[2]] = dataPoint[0];
    }
    
    public static void printArrayList(ArrayList<int[]> grid) {
        
    }
}
